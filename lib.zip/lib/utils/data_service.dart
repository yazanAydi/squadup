import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart';

class DataService {
  static final DataService _instance = DataService._internal();
  static DataService get instance => _instance;
  
  DataService._internal();

  late SharedPreferences _prefs;
  late FirebaseFirestore _firestore;
  bool _isInitialized = false;
  
  // Cache configuration
  static const int _maxCacheAge = 15 * 60 * 1000; // 15 minutes
  static const int _maxOfflineCacheAge = 24 * 60 * 60 * 1000; // 24 hours
  static const int _maxCacheSize = 50 * 1024 * 1024; // 50MB
  
  // Cache keys
  static const String _cacheTimestampKey = 'last_cache_update';
  static const String _offlineModeKey = 'offline_mode_enabled';
  static const String _cacheSizeKey = 'cache_size_bytes';
  static const String _userPreferencesKey = 'user_preferences';
  static const String _gameCacheKey = 'games_cache';
  static const String _teamCacheKey = 'teams_cache';
  static const String _userCacheKey = 'users_cache';

  /// Initialize the data service
  Future<void> initialize() async {
    if (_isInitialized) return;
    
    try {
      _prefs = await SharedPreferences.getInstance();
      _firestore = FirebaseFirestore.instance;
      
      // Enable offline persistence
      _firestore.settings = const Settings(
        persistenceEnabled: true,
        cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
      );
      
      _isInitialized = true;
      
      if (kDebugMode) {
        print('DataService initialized successfully');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error initializing DataService: $e');
      }
      rethrow;
    }
  }

  /// Check if device is offline
  Future<bool> get isOffline async {
    try {
      final connectivityResult = await Connectivity().checkConnectivity();
      return connectivityResult == ConnectivityResult.none;
    } catch (e) {
      return true; // Assume offline if connectivity check fails
    }
  }

  /// Check if we're using cached data
  bool get isUsingCache {
    if (!_isInitialized) return false;
    
    final lastUpdate = _prefs.getInt(_cacheTimestampKey) ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    
    return (now - lastUpdate) < _maxCacheAge;
  }

  /// Get cache statistics
  Map<String, dynamic> getCacheStats() {
    if (!_isInitialized) return {};
    
    final lastUpdate = _prefs.getInt(_cacheTimestampKey) ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    final cacheAge = now - lastUpdate;
    final isExpired = cacheAge > _maxCacheAge;
    final cacheSize = _prefs.getInt(_cacheSizeKey) ?? 0;
    
    return {
      'lastUpdate': lastUpdate > 0 ? DateTime.fromMillisecondsSinceEpoch(lastUpdate) : null,
      'cacheAge': cacheAge,
      'isExpired': isExpired,
      'cacheSize': cacheSize,
      'maxCacheAge': _maxCacheAge,
      'isOffline': false, // Will be updated by caller
    };
  }

  /// Intelligent data fetching with smart caching
  Future<T?> getDataWithCache<T>({
    required String cacheKey,
    required Future<T> Function() fetchFromServer,
    required T Function(Map<String, dynamic>) parseFromCache,
    required Map<String, dynamic> Function(T) serializeForCache,
    bool forceRefresh = false,
    int? customCacheAge,
  }) async {
    if (!_isInitialized) {
      await initialize();
    }

    final offline = await isOffline;
    final maxAge = customCacheAge ?? (offline ? _maxOfflineCacheAge : _maxCacheAge);
    
    // Check cache first (unless forcing refresh)
    if (!forceRefresh) {
      final cachedData = _getCachedData(cacheKey, maxAge);
      if (cachedData != null) {
        try {
          final parsed = parseFromCache(cachedData);
          if (kDebugMode) {
            print('Returning cached data for $cacheKey');
          }
          return parsed;
        } catch (e) {
          if (kDebugMode) {
            print('Error parsing cached data for $cacheKey: $e');
          }
          // Remove corrupted cache
          _removeCachedData(cacheKey);
        }
      }
    }

    // If offline and no valid cache, return null
    if (offline) {
      if (kDebugMode) {
        print('Offline and no valid cache for $cacheKey');
      }
      return null;
    }

    // Fetch from server
    try {
      final data = await fetchFromServer();
      
      // Cache the new data
      await _cacheData(cacheKey, serializeForCache(data));
      
      // Update cache timestamp
      await _updateCacheTimestamp();
      
      if (kDebugMode) {
        print('Fetched fresh data for $cacheKey');
      }
      
      return data;
    } catch (e) {
      if (kDebugMode) {
        print('Error fetching data for $cacheKey: $e');
      }
      
      // If fetch fails, try to return stale cache
      final staleCache = _getCachedData(cacheKey, _maxOfflineCacheAge);
      if (staleCache != null) {
        try {
          final parsed = parseFromCache(staleCache);
          if (kDebugMode) {
            print('Returning stale cache for $cacheKey due to fetch error');
          }
          return parsed;
        } catch (e) {
          if (kDebugMode) {
            print('Error parsing stale cache for $cacheKey: $e');
          }
        }
      }
      
      rethrow;
    }
  }

  /// Cache data with size management
  Future<void> _cacheData(String key, Map<String, dynamic> data) async {
    try {
      final jsonString = jsonEncode(data);
      final dataSize = utf8.encode(jsonString).length;
      
      // Check if adding this data would exceed cache size limit
      final currentSize = _prefs.getInt(_cacheSizeKey) ?? 0;
      if (currentSize + dataSize > _maxCacheSize) {
        await _cleanupCache();
      }
      
      await _prefs.setString(key, jsonString);
      await _prefs.setInt(_cacheSizeKey, currentSize + dataSize);
      
      if (kDebugMode) {
        print('Cached data for $key ($dataSize bytes)');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error caching data for $key: $e');
      }
    }
  }

  /// Get cached data if not expired
  Map<String, dynamic>? _getCachedData(String key, int maxAge) {
    try {
      final jsonString = _prefs.getString(key);
      if (jsonString == null) return null;
      
      final data = jsonDecode(jsonString) as Map<String, dynamic>;
      final timestamp = data['_cachedAt'] as int?;
      
      if (timestamp == null) return null;
      
      final now = DateTime.now().millisecondsSinceEpoch;
      if (now - timestamp > maxAge) {
        // Cache expired, remove it
        _removeCachedData(key);
        return null;
      }
      
      return data;
    } catch (e) {
      if (kDebugMode) {
        print('Error reading cached data for $key: $e');
      }
      return null;
    }
  }

  /// Remove cached data
  Future<void> _removeCachedData(String key) async {
    try {
      final jsonString = _prefs.getString(key);
      if (jsonString != null) {
        final dataSize = utf8.encode(jsonString).length;
        final currentSize = _prefs.getInt(_cacheSizeKey) ?? 0;
        
        await _prefs.remove(key);
        await _prefs.setInt(_cacheSizeKey, currentSize - dataSize);
        
        if (kDebugMode) {
          print('Removed cached data for $key');
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error removing cached data for $key: $e');
      }
    }
  }

  /// Cleanup cache to free space
  Future<void> _cleanupCache() async {
    try {
      final keys = _prefs.getKeys();
      final cacheKeys = keys.where((key) => 
        key.startsWith('cache_') || 
        key == _gameCacheKey || 
        key == _teamCacheKey || 
        key == _userCacheKey
      ).toList();
      
      // Sort by access time (oldest first)
      final cacheEntries = <MapEntry<String, int>>[];
      for (final key in cacheKeys) {
        final jsonString = _prefs.getString(key);
        if (jsonString != null) {
          try {
            final data = jsonDecode(jsonString) as Map<String, dynamic>;
            final timestamp = data['_cachedAt'] as int? ?? 0;
            cacheEntries.add(MapEntry(key, timestamp));
          } catch (e) {
            // Remove corrupted entries
            await _prefs.remove(key);
          }
        }
      }
      
      cacheEntries.sort((a, b) => a.value.compareTo(b.value));
      
      // Remove oldest entries until we're under the limit
      final currentSize = _prefs.getInt(_cacheSizeKey) ?? 0;
      final targetSize = _maxCacheSize * 0.8; // Target 80% of max size
      
      for (final entry in cacheEntries) {
        if (currentSize <= targetSize) break;
        
        await _removeCachedData(entry.key);
      }
      
      if (kDebugMode) {
        print('Cache cleanup completed');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error during cache cleanup: $e');
      }
    }
  }

  /// Update cache timestamp
  Future<void> _updateCacheTimestamp() async {
    final now = DateTime.now().millisecondsSinceEpoch;
    await _prefs.setInt(_cacheTimestampKey, now);
  }

  /// Refresh all cached data
  Future<void> refreshAllData() async {
    if (!_isInitialized) return;
    
    try {
      // Clear all cache timestamps to force refresh
      await _prefs.remove(_cacheTimestampKey);
      
      if (kDebugMode) {
        print('All cached data marked for refresh');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error refreshing all data: $e');
      }
    }
  }

  /// Clear all cached data
  Future<void> clearAllCache() async {
    if (!_isInitialized) return;
    
    try {
      final keys = _prefs.getKeys();
      final cacheKeys = keys.where((key) => 
        key.startsWith('cache_') || 
        key == _gameCacheKey || 
        key == _teamCacheKey || 
        key == _userCacheKey ||
        key == _cacheTimestampKey ||
        key == _cacheSizeKey
      ).toList();
      
      for (final key in cacheKeys) {
        await _prefs.remove(key);
      }
      
      if (kDebugMode) {
        print('All cached data cleared');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error clearing cache: $e');
      }
    }
  }

  /// Get user preferences
  Map<String, dynamic> getUserPreferences() {
    if (!_isInitialized) return {};
    
    try {
      final jsonString = _prefs.getString(_userPreferencesKey);
      if (jsonString != null) {
        return jsonDecode(jsonString) as Map<String, dynamic>;
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error reading user preferences: $e');
      }
    }
    
    return {};
  }

  /// Save user preferences
  Future<void> saveUserPreferences(Map<String, dynamic> preferences) async {
    if (!_isInitialized) return;
    
    try {
      final jsonString = jsonEncode(preferences);
      await _prefs.setString(_userPreferencesKey, jsonString);
      
      if (kDebugMode) {
        print('User preferences saved');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error saving user preferences: $e');
      }
    }
  }

  /// Check if offline mode is enabled
  bool get isOfflineModeEnabled {
    if (!_isInitialized) return false;
    return _prefs.getBool(_offlineModeKey) ?? false;
  }

  /// Toggle offline mode
  Future<void> toggleOfflineMode(bool enabled) async {
    if (!_isInitialized) return;
    
    try {
      await _prefs.setBool(_offlineModeKey, enabled);
      
      if (kDebugMode) {
        print('Offline mode ${enabled ? 'enabled' : 'disabled'}');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error toggling offline mode: $e');
      }
    }
  }

  /// Clear cache (alias for clearAllCache for backward compatibility)
  Future<void> clearCache() async {
    await clearAllCache();
  }

  /// Get user data with caching
  Future<Map<String, dynamic>?> getUserData({bool forceRefresh = false}) async {
    if (!_isInitialized) {
      await initialize();
    }

    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return null;

    return getDataWithCache<Map<String, dynamic>>(
      cacheKey: 'user_$uid',
      fetchFromServer: () async {
        final doc = await _firestore.collection('users').doc(uid).get();
        // ignore: unnecessary_cast
        final data = doc.data() as Map<String, dynamic>;
        return {'id': doc.id, ...data};
      },
      parseFromCache: (cachedData) => cachedData,
      serializeForCache: (data) => data,
      forceRefresh: forceRefresh,
    );
  }

  /// Get teams data with caching
  Future<List<Map<String, dynamic>>> getTeamsData({bool forceRefresh = false}) async {
    if (!_isInitialized) {
      await initialize();
    }

    final result = await getDataWithCache<List<Map<String, dynamic>>>(
      cacheKey: 'teams_all',
      fetchFromServer: () async {
        final snapshot = await _firestore.collection('teams').get();
        return snapshot.docs.map((doc) {
          // ignore: unnecessary_cast
          final data = doc.data() as Map<String, dynamic>;
          return {'id': doc.id, ...data};
        }).toList();
      },
      parseFromCache: (cachedData) => List<Map<String, dynamic>>.from(cachedData['teams'] ?? []),
      serializeForCache: (teams) => {'teams': teams, '_cachedAt': DateTime.now().millisecondsSinceEpoch},
      forceRefresh: forceRefresh,
    );

    return result ?? [];
  }

  /// Get games data with caching
  Future<List<Map<String, dynamic>>> getGamesData({bool forceRefresh = false}) async {
    if (!_isInitialized) {
      await initialize();
    }

    final result = await getDataWithCache<List<Map<String, dynamic>>>(
      cacheKey: 'games_all',
      fetchFromServer: () async {
        final snapshot = await _firestore.collection('games').get();
        return snapshot.docs.map((doc) {
          // ignore: unnecessary_cast
          final data = doc.data() as Map<String, dynamic>;
          return {'id': doc.id, ...data};
        }).toList();
      },
      parseFromCache: (cachedData) => List<Map<String, dynamic>>.from(cachedData['games'] ?? []),
      serializeForCache: (games) => {'games': games, '_cachedAt': DateTime.now().millisecondsSinceEpoch},
      forceRefresh: forceRefresh,
    );

    return result ?? [];
  }
}
