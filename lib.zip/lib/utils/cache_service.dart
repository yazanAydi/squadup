import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';

class CacheService {
  static const String _userDataKey = 'user_data';
  static const String _teamsDataKey = 'teams_data';
  static const String _gamesDataKey = 'games_data';
  static const String _lastUpdateKey = 'last_update';
  static const String _cacheExpiryKey = 'cache_expiry';
  
  // Cache expiry duration (24 hours)
  static const Duration _cacheExpiryDuration = Duration(hours: 24);
  
  static CacheService? _instance;
  static CacheService get instance => _instance ??= CacheService._();
  
  CacheService._();
  
  late SharedPreferences _prefs;
  
  /// Initialize the cache service
  Future<void> initialize() async {
    _prefs = await SharedPreferences.getInstance();
    if (kDebugMode) {
      print('Cache service initialized');
    }
  }
  
  /// Check if device has internet connection
  Future<bool> get hasInternetConnection async {
    final connectivityResult = await Connectivity().checkConnectivity();
    return connectivityResult != ConnectivityResult.none;
  }
  
  /// Check if cache is expired
  bool get isCacheExpired {
    final lastUpdate = _prefs.getInt(_lastUpdateKey) ?? 0;
    final expiryTime = _prefs.getInt(_cacheExpiryKey) ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    
    return now > expiryTime || (now - lastUpdate) > _cacheExpiryDuration.inMilliseconds;
  }
  
  /// Get last update timestamp
  DateTime? get lastUpdate {
    final timestamp = _prefs.getInt(_lastUpdateKey);
    return timestamp != null ? DateTime.fromMillisecondsSinceEpoch(timestamp) : null;
  }
  
  /// Set cache expiry time
  Future<void> _setCacheExpiry() async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final expiryTime = now + _cacheExpiryDuration.inMilliseconds;
    
    await _prefs.setInt(_lastUpdateKey, now);
    await _prefs.setInt(_cacheExpiryKey, expiryTime);
  }
  
  // User Data Caching
  Future<void> cacheUserData(Map<String, dynamic> userData) async {
    try {
      final jsonData = jsonEncode(userData);
      await _prefs.setString(_userDataKey, jsonData);
      await _setCacheExpiry();
      
      if (kDebugMode) {
        print('User data cached successfully');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error caching user data: $e');
      }
    }
  }
  
  Map<String, dynamic>? getCachedUserData() {
    try {
      final jsonData = _prefs.getString(_userDataKey);
      if (jsonData != null) {
        return jsonDecode(jsonData) as Map<String, dynamic>;
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error retrieving cached user data: $e');
      }
    }
    return null;
  }
  
  // Teams Data Caching
  Future<void> cacheTeamsData(List<Map<String, dynamic>> teams) async {
    try {
      final jsonData = jsonEncode(teams);
      await _prefs.setString(_teamsDataKey, jsonData);
      await _setCacheExpiry();
      
      if (kDebugMode) {
        print('Teams data cached successfully (${teams.length} teams)');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error caching teams data: $e');
      }
    }
  }
  
  List<Map<String, dynamic>> getCachedTeamsData() {
    try {
      final jsonData = _prefs.getString(_teamsDataKey);
      if (jsonData != null) {
        final List<dynamic> decoded = jsonDecode(jsonData);
        return decoded.map((item) => item as Map<String, dynamic>).toList();
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error retrieving cached teams data: $e');
      }
    }
    return [];
  }
  
  // Games Data Caching
  Future<void> cacheGamesData(List<Map<String, dynamic>> games) async {
    try {
      final jsonData = jsonEncode(games);
      await _prefs.setString(_gamesDataKey, jsonData);
      await _setCacheExpiry();
      
      if (kDebugMode) {
        print('Games data cached successfully (${games.length} games)');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error caching games data: $e');
      }
    }
  }
  
  List<Map<String, dynamic>> getCachedGamesData() {
    try {
      final jsonData = _prefs.getString(_gamesDataKey);
      if (jsonData != null) {
        final List<dynamic> decoded = jsonDecode(jsonData);
        return decoded.map((item) => item as Map<String, dynamic>).toList();
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error retrieving cached games data: $e');
      }
    }
    return [];
  }
  
  // Generic Data Caching
  Future<void> cacheData(String key, dynamic data) async {
    try {
      final jsonData = jsonEncode(data);
      await _prefs.setString(key, jsonData);
      await _setCacheExpiry();
      
      if (kDebugMode) {
        print('Data cached successfully for key: $key');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error caching data for key $key: $e');
      }
    }
  }
  
  T? getCachedData<T>(String key, T Function(Map<String, dynamic>) fromJson) {
    try {
      final jsonData = _prefs.getString(key);
      if (jsonData != null) {
        final Map<String, dynamic> decoded = jsonDecode(jsonData);
        return fromJson(decoded);
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error retrieving cached data for key $key: $e');
      }
    }
    return null;
  }
  
  // Cache Management
  Future<void> clearCache() async {
    try {
      await _prefs.remove(_userDataKey);
      await _prefs.remove(_teamsDataKey);
      await _prefs.remove(_gamesDataKey);
      await _prefs.remove(_lastUpdateKey);
      await _prefs.remove(_cacheExpiryKey);
      
      if (kDebugMode) {
        print('Cache cleared successfully');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error clearing cache: $e');
      }
    }
  }
  
  Future<void> clearExpiredCache() async {
    if (isCacheExpired) {
      await clearCache();
      if (kDebugMode) {
        print('Expired cache cleared');
      }
    }
  }
  
  // Cache Statistics
  Map<String, dynamic> getCacheStats() {
    final lastUpdate = this.lastUpdate;
    final isExpired = isCacheExpired;
    
    return {
      'lastUpdate': lastUpdate?.toIso8601String(),
      'isExpired': isExpired,
      'hasUserData': _prefs.containsKey(_userDataKey),
      'hasTeamsData': _prefs.containsKey(_teamsDataKey),
      'hasGamesData': _prefs.containsKey(_gamesDataKey),
      'cacheSize': _getCacheSize(),
    };
  }
  
  int _getCacheSize() {
    int totalSize = 0;
    final keys = [_userDataKey, _teamsDataKey, _gamesDataKey];
    
    for (final key in keys) {
      final data = _prefs.getString(key);
      if (data != null) {
        totalSize += data.length;
      }
    }
    
    return totalSize;
  }
}
