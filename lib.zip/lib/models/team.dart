class Team {
  final String id;
  final String name;
  final String sport;
  final String location;
  final int memberCount;
  final String createdAt;
  final String? description;
  final String? imageUrl;
  final List<String> members;
  final String ownerId;

  const Team({
    required this.id,
    required this.name,
    required this.sport,
    required this.location,
    required this.memberCount,
    required this.createdAt,
    this.description,
    this.imageUrl,
    required this.members,
    required this.ownerId,
  });

  factory Team.fromMap(Map<String, dynamic> map, String id) {
    return Team(
      id: id,
      name: map['name'] ?? '',
      sport: map['sport'] ?? '',
      location: map['location'] ?? '',
      memberCount: map['memberCount']?.toInt() ?? 0,
      createdAt: map['createdAt'] ?? '',
      description: map['description'],
      imageUrl: map['imageUrl'],
      members: List<String>.from(map['members'] ?? []),
      ownerId: map['ownerId'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'sport': sport,
      'location': location,
      'memberCount': memberCount,
      'createdAt': createdAt,
      'description': description,
      'imageUrl': imageUrl,
      'members': members,
      'ownerId': ownerId,
    };
  }

  Team copyWith({
    String? id,
    String? name,
    String? sport,
    String? location,
    int? memberCount,
    String? createdAt,
    String? description,
    String? imageUrl,
    List<String>? members,
    String? ownerId,
  }) {
    return Team(
      id: id ?? this.id,
      name: name ?? this.name,
      sport: sport ?? this.sport,
      location: location ?? this.location,
      memberCount: memberCount ?? this.memberCount,
      createdAt: createdAt ?? this.createdAt,
      description: description ?? this.description,
      imageUrl: imageUrl ?? this.imageUrl,
      members: members ?? this.members,
      ownerId: ownerId ?? this.ownerId,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Team &&
          runtimeType == other.runtimeType &&
          id == other.id &&
          name == other.name &&
          sport == other.sport &&
          location == other.location &&
          memberCount == other.memberCount;

  @override
  int get hashCode =>
      id.hashCode ^
      name.hashCode ^
      sport.hashCode ^
      location.hashCode ^
      memberCount.hashCode;

  @override
  String toString() {
    return 'Team(id: $id, name: $name, sport: $sport, location: $location, memberCount: $memberCount)';
  }
}
